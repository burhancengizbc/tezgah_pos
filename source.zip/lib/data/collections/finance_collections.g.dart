// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'finance_collections.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetCashSessionCollection on Isar {
  IsarCollection<CashSession> get cashSessions => this.collection();
}

const CashSessionSchema = CollectionSchema(
  name: r'CashSession',
  id: -828438757725199893,
  properties: {
    r'cardSalesKurus': PropertySchema(
      id: 0,
      name: r'cardSalesKurus',
      type: IsarType.long,
    ),
    r'cashInKurus': PropertySchema(
      id: 1,
      name: r'cashInKurus',
      type: IsarType.long,
    ),
    r'cashOutKurus': PropertySchema(
      id: 2,
      name: r'cashOutKurus',
      type: IsarType.long,
    ),
    r'cashSalesKurus': PropertySchema(
      id: 3,
      name: r'cashSalesKurus',
      type: IsarType.long,
    ),
    r'closedAt': PropertySchema(
      id: 4,
      name: r'closedAt',
      type: IsarType.dateTime,
    ),
    r'countedCashKurus': PropertySchema(
      id: 5,
      name: r'countedCashKurus',
      type: IsarType.long,
    ),
    r'differenceKurus': PropertySchema(
      id: 6,
      name: r'differenceKurus',
      type: IsarType.long,
    ),
    r'expectedCashKurus': PropertySchema(
      id: 7,
      name: r'expectedCashKurus',
      type: IsarType.long,
    ),
    r'isOpen': PropertySchema(
      id: 8,
      name: r'isOpen',
      type: IsarType.bool,
    ),
    r'note': PropertySchema(
      id: 9,
      name: r'note',
      type: IsarType.string,
    ),
    r'openedAt': PropertySchema(
      id: 10,
      name: r'openedAt',
      type: IsarType.dateTime,
    ),
    r'openingFloatKurus': PropertySchema(
      id: 11,
      name: r'openingFloatKurus',
      type: IsarType.long,
    ),
    r'operatorName': PropertySchema(
      id: 12,
      name: r'operatorName',
      type: IsarType.string,
    ),
    r'otherSalesKurus': PropertySchema(
      id: 13,
      name: r'otherSalesKurus',
      type: IsarType.long,
    ),
    r'totalSalesKurus': PropertySchema(
      id: 14,
      name: r'totalSalesKurus',
      type: IsarType.long,
    )
  },
  estimateSize: _cashSessionEstimateSize,
  serialize: _cashSessionSerialize,
  deserialize: _cashSessionDeserialize,
  deserializeProp: _cashSessionDeserializeProp,
  idName: r'id',
  indexes: {
    r'openedAt': IndexSchema(
      id: -5170574981129517220,
      name: r'openedAt',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'openedAt',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _cashSessionGetId,
  getLinks: _cashSessionGetLinks,
  attach: _cashSessionAttach,
  version: '3.3.2',
);

int _cashSessionEstimateSize(
  CashSession object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.note.length * 3;
  {
    final value = object.operatorName;
    if (value != null) {
      bytesCount += 3 + value.length * 3;
    }
  }
  return bytesCount;
}

void _cashSessionSerialize(
  CashSession object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.cardSalesKurus);
  writer.writeLong(offsets[1], object.cashInKurus);
  writer.writeLong(offsets[2], object.cashOutKurus);
  writer.writeLong(offsets[3], object.cashSalesKurus);
  writer.writeDateTime(offsets[4], object.closedAt);
  writer.writeLong(offsets[5], object.countedCashKurus);
  writer.writeLong(offsets[6], object.differenceKurus);
  writer.writeLong(offsets[7], object.expectedCashKurus);
  writer.writeBool(offsets[8], object.isOpen);
  writer.writeString(offsets[9], object.note);
  writer.writeDateTime(offsets[10], object.openedAt);
  writer.writeLong(offsets[11], object.openingFloatKurus);
  writer.writeString(offsets[12], object.operatorName);
  writer.writeLong(offsets[13], object.otherSalesKurus);
  writer.writeLong(offsets[14], object.totalSalesKurus);
}

CashSession _cashSessionDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = CashSession();
  object.cardSalesKurus = reader.readLong(offsets[0]);
  object.cashInKurus = reader.readLong(offsets[1]);
  object.cashOutKurus = reader.readLong(offsets[2]);
  object.cashSalesKurus = reader.readLong(offsets[3]);
  object.closedAt = reader.readDateTimeOrNull(offsets[4]);
  object.countedCashKurus = reader.readLong(offsets[5]);
  object.differenceKurus = reader.readLongOrNull(offsets[6]);
  object.id = id;
  object.isOpen = reader.readBool(offsets[8]);
  object.note = reader.readString(offsets[9]);
  object.openedAt = reader.readDateTime(offsets[10]);
  object.openingFloatKurus = reader.readLong(offsets[11]);
  object.operatorName = reader.readStringOrNull(offsets[12]);
  object.otherSalesKurus = reader.readLong(offsets[13]);
  object.totalSalesKurus = reader.readLong(offsets[14]);
  return object;
}

P _cashSessionDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    case 1:
      return (reader.readLong(offset)) as P;
    case 2:
      return (reader.readLong(offset)) as P;
    case 3:
      return (reader.readLong(offset)) as P;
    case 4:
      return (reader.readDateTimeOrNull(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    case 6:
      return (reader.readLongOrNull(offset)) as P;
    case 7:
      return (reader.readLong(offset)) as P;
    case 8:
      return (reader.readBool(offset)) as P;
    case 9:
      return (reader.readString(offset)) as P;
    case 10:
      return (reader.readDateTime(offset)) as P;
    case 11:
      return (reader.readLong(offset)) as P;
    case 12:
      return (reader.readStringOrNull(offset)) as P;
    case 13:
      return (reader.readLong(offset)) as P;
    case 14:
      return (reader.readLong(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _cashSessionGetId(CashSession object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _cashSessionGetLinks(CashSession object) {
  return [];
}

void _cashSessionAttach(
    IsarCollection<dynamic> col, Id id, CashSession object) {
  object.id = id;
}

extension CashSessionQueryWhereSort
    on QueryBuilder<CashSession, CashSession, QWhere> {
  QueryBuilder<CashSession, CashSession, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhere> anyOpenedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'openedAt'),
      );
    });
  }
}

extension CashSessionQueryWhere
    on QueryBuilder<CashSession, CashSession, QWhereClause> {
  QueryBuilder<CashSession, CashSession, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> openedAtEqualTo(
      DateTime openedAt) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'openedAt',
        value: [openedAt],
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> openedAtNotEqualTo(
      DateTime openedAt) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'openedAt',
              lower: [],
              upper: [openedAt],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'openedAt',
              lower: [openedAt],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'openedAt',
              lower: [openedAt],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'openedAt',
              lower: [],
              upper: [openedAt],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> openedAtGreaterThan(
    DateTime openedAt, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'openedAt',
        lower: [openedAt],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> openedAtLessThan(
    DateTime openedAt, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'openedAt',
        lower: [],
        upper: [openedAt],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterWhereClause> openedAtBetween(
    DateTime lowerOpenedAt,
    DateTime upperOpenedAt, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'openedAt',
        lower: [lowerOpenedAt],
        includeLower: includeLower,
        upper: [upperOpenedAt],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CashSessionQueryFilter
    on QueryBuilder<CashSession, CashSession, QFilterCondition> {
  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cardSalesKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'cardSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cardSalesKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'cardSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cardSalesKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'cardSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cardSalesKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'cardSalesKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashInKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'cashInKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashInKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'cashInKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashInKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'cashInKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashInKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'cashInKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashOutKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'cashOutKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashOutKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'cashOutKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashOutKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'cashOutKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashOutKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'cashOutKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashSalesKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'cashSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashSalesKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'cashSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashSalesKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'cashSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      cashSalesKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'cashSalesKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      closedAtIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'closedAt',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      closedAtIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'closedAt',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> closedAtEqualTo(
      DateTime? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'closedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      closedAtGreaterThan(
    DateTime? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'closedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      closedAtLessThan(
    DateTime? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'closedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> closedAtBetween(
    DateTime? lower,
    DateTime? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'closedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      countedCashKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'countedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      countedCashKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'countedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      countedCashKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'countedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      countedCashKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'countedCashKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'differenceKurus',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'differenceKurus',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'differenceKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'differenceKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'differenceKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      differenceKurusBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'differenceKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      expectedCashKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'expectedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      expectedCashKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'expectedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      expectedCashKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'expectedCashKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      expectedCashKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'expectedCashKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> isOpenEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isOpen',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'note',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'note',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> noteIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      noteIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> openedAtEqualTo(
      DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'openedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openedAtGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'openedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openedAtLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'openedAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition> openedAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'openedAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openingFloatKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'openingFloatKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openingFloatKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'openingFloatKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openingFloatKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'openingFloatKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      openingFloatKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'openingFloatKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'operatorName',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'operatorName',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameEqualTo(
    String? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameGreaterThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameLessThan(
    String? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameBetween(
    String? lower,
    String? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'operatorName',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'operatorName',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'operatorName',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'operatorName',
        value: '',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      operatorNameIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'operatorName',
        value: '',
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      otherSalesKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'otherSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      otherSalesKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'otherSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      otherSalesKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'otherSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      otherSalesKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'otherSalesKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      totalSalesKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'totalSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      totalSalesKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'totalSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      totalSalesKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'totalSalesKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterFilterCondition>
      totalSalesKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'totalSalesKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CashSessionQueryObject
    on QueryBuilder<CashSession, CashSession, QFilterCondition> {}

extension CashSessionQueryLinks
    on QueryBuilder<CashSession, CashSession, QFilterCondition> {}

extension CashSessionQuerySortBy
    on QueryBuilder<CashSession, CashSession, QSortBy> {
  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByCardSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cardSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByCardSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cardSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByCashInKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashInKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByCashInKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashInKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByCashOutKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashOutKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByCashOutKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashOutKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByCashSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByCashSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByClosedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'closedAt', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByClosedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'closedAt', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByCountedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'countedCashKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByCountedCashKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'countedCashKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByDifferenceKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'differenceKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByDifferenceKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'differenceKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByExpectedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expectedCashKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByExpectedCashKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expectedCashKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByIsOpen() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isOpen', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByIsOpenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isOpen', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByOpenedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openedAt', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByOpenedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openedAt', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByOpeningFloatKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openingFloatKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByOpeningFloatKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openingFloatKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByOperatorName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'operatorName', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByOperatorNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'operatorName', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByOtherSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'otherSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByOtherSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'otherSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> sortByTotalSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'totalSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      sortByTotalSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'totalSalesKurus', Sort.desc);
    });
  }
}

extension CashSessionQuerySortThenBy
    on QueryBuilder<CashSession, CashSession, QSortThenBy> {
  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByCardSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cardSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByCardSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cardSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByCashInKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashInKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByCashInKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashInKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByCashOutKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashOutKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByCashOutKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashOutKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByCashSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByCashSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'cashSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByClosedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'closedAt', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByClosedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'closedAt', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByCountedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'countedCashKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByCountedCashKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'countedCashKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByDifferenceKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'differenceKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByDifferenceKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'differenceKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByExpectedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expectedCashKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByExpectedCashKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expectedCashKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByIsOpen() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isOpen', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByIsOpenDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isOpen', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByOpenedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openedAt', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByOpenedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openedAt', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByOpeningFloatKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openingFloatKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByOpeningFloatKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'openingFloatKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByOperatorName() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'operatorName', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByOperatorNameDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'operatorName', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByOtherSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'otherSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByOtherSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'otherSalesKurus', Sort.desc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy> thenByTotalSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'totalSalesKurus', Sort.asc);
    });
  }

  QueryBuilder<CashSession, CashSession, QAfterSortBy>
      thenByTotalSalesKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'totalSalesKurus', Sort.desc);
    });
  }
}

extension CashSessionQueryWhereDistinct
    on QueryBuilder<CashSession, CashSession, QDistinct> {
  QueryBuilder<CashSession, CashSession, QDistinct> distinctByCardSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'cardSalesKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByCashInKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'cashInKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByCashOutKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'cashOutKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByCashSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'cashSalesKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByClosedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'closedAt');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByCountedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'countedCashKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByDifferenceKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'differenceKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByExpectedCashKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'expectedCashKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByIsOpen() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isOpen');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByNote(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'note', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByOpenedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'openedAt');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByOpeningFloatKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'openingFloatKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct> distinctByOperatorName(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'operatorName', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByOtherSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'otherSalesKurus');
    });
  }

  QueryBuilder<CashSession, CashSession, QDistinct>
      distinctByTotalSalesKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'totalSalesKurus');
    });
  }
}

extension CashSessionQueryProperty
    on QueryBuilder<CashSession, CashSession, QQueryProperty> {
  QueryBuilder<CashSession, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> cardSalesKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'cardSalesKurus');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> cashInKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'cashInKurus');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> cashOutKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'cashOutKurus');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> cashSalesKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'cashSalesKurus');
    });
  }

  QueryBuilder<CashSession, DateTime?, QQueryOperations> closedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'closedAt');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> countedCashKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'countedCashKurus');
    });
  }

  QueryBuilder<CashSession, int?, QQueryOperations> differenceKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'differenceKurus');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> expectedCashKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'expectedCashKurus');
    });
  }

  QueryBuilder<CashSession, bool, QQueryOperations> isOpenProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isOpen');
    });
  }

  QueryBuilder<CashSession, String, QQueryOperations> noteProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'note');
    });
  }

  QueryBuilder<CashSession, DateTime, QQueryOperations> openedAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'openedAt');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> openingFloatKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'openingFloatKurus');
    });
  }

  QueryBuilder<CashSession, String?, QQueryOperations> operatorNameProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'operatorName');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> otherSalesKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'otherSalesKurus');
    });
  }

  QueryBuilder<CashSession, int, QQueryOperations> totalSalesKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'totalSalesKurus');
    });
  }
}

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetCashMovementCollection on Isar {
  IsarCollection<CashMovement> get cashMovements => this.collection();
}

const CashMovementSchema = CollectionSchema(
  name: r'CashMovement',
  id: -8008726333504533645,
  properties: {
    r'amountKurus': PropertySchema(
      id: 0,
      name: r'amountKurus',
      type: IsarType.long,
    ),
    r'createdAt': PropertySchema(
      id: 1,
      name: r'createdAt',
      type: IsarType.dateTime,
    ),
    r'note': PropertySchema(
      id: 2,
      name: r'note',
      type: IsarType.string,
    ),
    r'reason': PropertySchema(
      id: 3,
      name: r'reason',
      type: IsarType.string,
    ),
    r'refOrderId': PropertySchema(
      id: 4,
      name: r'refOrderId',
      type: IsarType.long,
    ),
    r'sessionId': PropertySchema(
      id: 5,
      name: r'sessionId',
      type: IsarType.long,
    ),
    r'type': PropertySchema(
      id: 6,
      name: r'type',
      type: IsarType.string,
      enumMap: _CashMovementtypeEnumValueMap,
    )
  },
  estimateSize: _cashMovementEstimateSize,
  serialize: _cashMovementSerialize,
  deserialize: _cashMovementDeserialize,
  deserializeProp: _cashMovementDeserializeProp,
  idName: r'id',
  indexes: {
    r'sessionId': IndexSchema(
      id: 6949518585047923839,
      name: r'sessionId',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'sessionId',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'createdAt': IndexSchema(
      id: -3433535483987302584,
      name: r'createdAt',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'createdAt',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _cashMovementGetId,
  getLinks: _cashMovementGetLinks,
  attach: _cashMovementAttach,
  version: '3.3.2',
);

int _cashMovementEstimateSize(
  CashMovement object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.note.length * 3;
  bytesCount += 3 + object.reason.length * 3;
  bytesCount += 3 + object.type.name.length * 3;
  return bytesCount;
}

void _cashMovementSerialize(
  CashMovement object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.amountKurus);
  writer.writeDateTime(offsets[1], object.createdAt);
  writer.writeString(offsets[2], object.note);
  writer.writeString(offsets[3], object.reason);
  writer.writeLong(offsets[4], object.refOrderId);
  writer.writeLong(offsets[5], object.sessionId);
  writer.writeString(offsets[6], object.type.name);
}

CashMovement _cashMovementDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = CashMovement();
  object.amountKurus = reader.readLong(offsets[0]);
  object.createdAt = reader.readDateTime(offsets[1]);
  object.id = id;
  object.note = reader.readString(offsets[2]);
  object.reason = reader.readString(offsets[3]);
  object.refOrderId = reader.readLongOrNull(offsets[4]);
  object.sessionId = reader.readLong(offsets[5]);
  object.type =
      _CashMovementtypeValueEnumMap[reader.readStringOrNull(offsets[6])] ??
          CashMovementType.open;
  return object;
}

P _cashMovementDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    case 1:
      return (reader.readDateTime(offset)) as P;
    case 2:
      return (reader.readString(offset)) as P;
    case 3:
      return (reader.readString(offset)) as P;
    case 4:
      return (reader.readLongOrNull(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    case 6:
      return (_CashMovementtypeValueEnumMap[reader.readStringOrNull(offset)] ??
          CashMovementType.open) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

const _CashMovementtypeEnumValueMap = {
  r'open': r'open',
  r'close': r'close',
  r'sale': r'sale',
  r'refund': r'refund',
  r'cashIn': r'cashIn',
  r'cashOut': r'cashOut',
};
const _CashMovementtypeValueEnumMap = {
  r'open': CashMovementType.open,
  r'close': CashMovementType.close,
  r'sale': CashMovementType.sale,
  r'refund': CashMovementType.refund,
  r'cashIn': CashMovementType.cashIn,
  r'cashOut': CashMovementType.cashOut,
};

Id _cashMovementGetId(CashMovement object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _cashMovementGetLinks(CashMovement object) {
  return [];
}

void _cashMovementAttach(
    IsarCollection<dynamic> col, Id id, CashMovement object) {
  object.id = id;
}

extension CashMovementQueryWhereSort
    on QueryBuilder<CashMovement, CashMovement, QWhere> {
  QueryBuilder<CashMovement, CashMovement, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhere> anySessionId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'sessionId'),
      );
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhere> anyCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'createdAt'),
      );
    });
  }
}

extension CashMovementQueryWhere
    on QueryBuilder<CashMovement, CashMovement, QWhereClause> {
  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> idNotEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> idGreaterThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> sessionIdEqualTo(
      int sessionId) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'sessionId',
        value: [sessionId],
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause>
      sessionIdNotEqualTo(int sessionId) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sessionId',
              lower: [],
              upper: [sessionId],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sessionId',
              lower: [sessionId],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sessionId',
              lower: [sessionId],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'sessionId',
              lower: [],
              upper: [sessionId],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause>
      sessionIdGreaterThan(
    int sessionId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'sessionId',
        lower: [sessionId],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> sessionIdLessThan(
    int sessionId, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'sessionId',
        lower: [],
        upper: [sessionId],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> sessionIdBetween(
    int lowerSessionId,
    int upperSessionId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'sessionId',
        lower: [lowerSessionId],
        includeLower: includeLower,
        upper: [upperSessionId],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> createdAtEqualTo(
      DateTime createdAt) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'createdAt',
        value: [createdAt],
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause>
      createdAtNotEqualTo(DateTime createdAt) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'createdAt',
              lower: [],
              upper: [createdAt],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'createdAt',
              lower: [createdAt],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'createdAt',
              lower: [createdAt],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'createdAt',
              lower: [],
              upper: [createdAt],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause>
      createdAtGreaterThan(
    DateTime createdAt, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'createdAt',
        lower: [createdAt],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> createdAtLessThan(
    DateTime createdAt, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'createdAt',
        lower: [],
        upper: [createdAt],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterWhereClause> createdAtBetween(
    DateTime lowerCreatedAt,
    DateTime upperCreatedAt, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'createdAt',
        lower: [lowerCreatedAt],
        includeLower: includeLower,
        upper: [upperCreatedAt],
        includeUpper: includeUpper,
      ));
    });
  }
}

extension CashMovementQueryFilter
    on QueryBuilder<CashMovement, CashMovement, QFilterCondition> {
  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      amountKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      amountKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      amountKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      amountKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'amountKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      createdAtEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      createdAtGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      createdAtLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      createdAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'createdAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      noteGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'note',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      noteStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> noteMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'note',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      noteIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      noteIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> reasonEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> reasonBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'reason',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'reason',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> reasonMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'reason',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'reason',
        value: '',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      reasonIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'reason',
        value: '',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'refOrderId',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'refOrderId',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      refOrderIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'refOrderId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      sessionIdEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'sessionId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      sessionIdGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'sessionId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      sessionIdLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'sessionId',
        value: value,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      sessionIdBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'sessionId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeEqualTo(
    CashMovementType value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      typeGreaterThan(
    CashMovementType value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeLessThan(
    CashMovementType value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeBetween(
    CashMovementType lower,
    CashMovementType upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'type',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      typeStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeContains(
      String value,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'type',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition> typeMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'type',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      typeIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'type',
        value: '',
      ));
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterFilterCondition>
      typeIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'type',
        value: '',
      ));
    });
  }
}

extension CashMovementQueryObject
    on QueryBuilder<CashMovement, CashMovement, QFilterCondition> {}

extension CashMovementQueryLinks
    on QueryBuilder<CashMovement, CashMovement, QFilterCondition> {}

extension CashMovementQuerySortBy
    on QueryBuilder<CashMovement, CashMovement, QSortBy> {
  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy>
      sortByAmountKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByReason() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'reason', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByReasonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'reason', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy>
      sortByRefOrderIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortBySessionId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sessionId', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortBySessionIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sessionId', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> sortByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }
}

extension CashMovementQuerySortThenBy
    on QueryBuilder<CashMovement, CashMovement, QSortThenBy> {
  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy>
      thenByAmountKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByReason() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'reason', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByReasonDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'reason', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy>
      thenByRefOrderIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenBySessionId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sessionId', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenBySessionIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'sessionId', Sort.desc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByType() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.asc);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QAfterSortBy> thenByTypeDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'type', Sort.desc);
    });
  }
}

extension CashMovementQueryWhereDistinct
    on QueryBuilder<CashMovement, CashMovement, QDistinct> {
  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'amountKurus');
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'createdAt');
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByNote(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'note', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByReason(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'reason', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'refOrderId');
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctBySessionId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'sessionId');
    });
  }

  QueryBuilder<CashMovement, CashMovement, QDistinct> distinctByType(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'type', caseSensitive: caseSensitive);
    });
  }
}

extension CashMovementQueryProperty
    on QueryBuilder<CashMovement, CashMovement, QQueryProperty> {
  QueryBuilder<CashMovement, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<CashMovement, int, QQueryOperations> amountKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'amountKurus');
    });
  }

  QueryBuilder<CashMovement, DateTime, QQueryOperations> createdAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'createdAt');
    });
  }

  QueryBuilder<CashMovement, String, QQueryOperations> noteProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'note');
    });
  }

  QueryBuilder<CashMovement, String, QQueryOperations> reasonProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'reason');
    });
  }

  QueryBuilder<CashMovement, int?, QQueryOperations> refOrderIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'refOrderId');
    });
  }

  QueryBuilder<CashMovement, int, QQueryOperations> sessionIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'sessionId');
    });
  }

  QueryBuilder<CashMovement, CashMovementType, QQueryOperations>
      typeProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'type');
    });
  }
}

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetAccountingEntryCollection on Isar {
  IsarCollection<AccountingEntry> get accountingEntrys => this.collection();
}

const AccountingEntrySchema = CollectionSchema(
  name: r'AccountingEntry',
  id: 3375140915352623079,
  properties: {
    r'amountKurus': PropertySchema(
      id: 0,
      name: r'amountKurus',
      type: IsarType.long,
    ),
    r'createdAt': PropertySchema(
      id: 1,
      name: r'createdAt',
      type: IsarType.dateTime,
    ),
    r'date': PropertySchema(
      id: 2,
      name: r'date',
      type: IsarType.dateTime,
    ),
    r'expenseCategory': PropertySchema(
      id: 3,
      name: r'expenseCategory',
      type: IsarType.string,
      enumMap: _AccountingEntryexpenseCategoryEnumValueMap,
    ),
    r'incomeCategory': PropertySchema(
      id: 4,
      name: r'incomeCategory',
      type: IsarType.string,
      enumMap: _AccountingEntryincomeCategoryEnumValueMap,
    ),
    r'isDeleted': PropertySchema(
      id: 5,
      name: r'isDeleted',
      type: IsarType.bool,
    ),
    r'kind': PropertySchema(
      id: 6,
      name: r'kind',
      type: IsarType.string,
      enumMap: _AccountingEntrykindEnumValueMap,
    ),
    r'note': PropertySchema(
      id: 7,
      name: r'note',
      type: IsarType.string,
    ),
    r'refOrderId': PropertySchema(
      id: 8,
      name: r'refOrderId',
      type: IsarType.long,
    ),
    r'title': PropertySchema(
      id: 9,
      name: r'title',
      type: IsarType.string,
    )
  },
  estimateSize: _accountingEntryEstimateSize,
  serialize: _accountingEntrySerialize,
  deserialize: _accountingEntryDeserialize,
  deserializeProp: _accountingEntryDeserializeProp,
  idName: r'id',
  indexes: {
    r'date': IndexSchema(
      id: -7552997827385218417,
      name: r'date',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'date',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    ),
    r'isDeleted': IndexSchema(
      id: -786475870904832312,
      name: r'isDeleted',
      unique: false,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'isDeleted',
          type: IndexType.value,
          caseSensitive: false,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _accountingEntryGetId,
  getLinks: _accountingEntryGetLinks,
  attach: _accountingEntryAttach,
  version: '3.3.2',
);

int _accountingEntryEstimateSize(
  AccountingEntry object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  {
    final value = object.expenseCategory;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  {
    final value = object.incomeCategory;
    if (value != null) {
      bytesCount += 3 + value.name.length * 3;
    }
  }
  bytesCount += 3 + object.kind.name.length * 3;
  bytesCount += 3 + object.note.length * 3;
  bytesCount += 3 + object.title.length * 3;
  return bytesCount;
}

void _accountingEntrySerialize(
  AccountingEntry object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeLong(offsets[0], object.amountKurus);
  writer.writeDateTime(offsets[1], object.createdAt);
  writer.writeDateTime(offsets[2], object.date);
  writer.writeString(offsets[3], object.expenseCategory?.name);
  writer.writeString(offsets[4], object.incomeCategory?.name);
  writer.writeBool(offsets[5], object.isDeleted);
  writer.writeString(offsets[6], object.kind.name);
  writer.writeString(offsets[7], object.note);
  writer.writeLong(offsets[8], object.refOrderId);
  writer.writeString(offsets[9], object.title);
}

AccountingEntry _accountingEntryDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = AccountingEntry();
  object.amountKurus = reader.readLong(offsets[0]);
  object.createdAt = reader.readDateTime(offsets[1]);
  object.date = reader.readDateTime(offsets[2]);
  object.expenseCategory = _AccountingEntryexpenseCategoryValueEnumMap[
      reader.readStringOrNull(offsets[3])];
  object.id = id;
  object.incomeCategory = _AccountingEntryincomeCategoryValueEnumMap[
      reader.readStringOrNull(offsets[4])];
  object.isDeleted = reader.readBool(offsets[5]);
  object.kind =
      _AccountingEntrykindValueEnumMap[reader.readStringOrNull(offsets[6])] ??
          AccountingKind.income;
  object.note = reader.readString(offsets[7]);
  object.refOrderId = reader.readLongOrNull(offsets[8]);
  object.title = reader.readString(offsets[9]);
  return object;
}

P _accountingEntryDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readLong(offset)) as P;
    case 1:
      return (reader.readDateTime(offset)) as P;
    case 2:
      return (reader.readDateTime(offset)) as P;
    case 3:
      return (_AccountingEntryexpenseCategoryValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 4:
      return (_AccountingEntryincomeCategoryValueEnumMap[
          reader.readStringOrNull(offset)]) as P;
    case 5:
      return (reader.readBool(offset)) as P;
    case 6:
      return (_AccountingEntrykindValueEnumMap[
              reader.readStringOrNull(offset)] ??
          AccountingKind.income) as P;
    case 7:
      return (reader.readString(offset)) as P;
    case 8:
      return (reader.readLongOrNull(offset)) as P;
    case 9:
      return (reader.readString(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

const _AccountingEntryexpenseCategoryEnumValueMap = {
  r'personnel': r'personnel',
  r'rent': r'rent',
  r'electricity': r'electricity',
  r'water': r'water',
  r'gas': r'gas',
  r'internet': r'internet',
  r'tax': r'tax',
  r'supplies': r'supplies',
  r'maintenance': r'maintenance',
  r'other': r'other',
};
const _AccountingEntryexpenseCategoryValueEnumMap = {
  r'personnel': ExpenseCategory.personnel,
  r'rent': ExpenseCategory.rent,
  r'electricity': ExpenseCategory.electricity,
  r'water': ExpenseCategory.water,
  r'gas': ExpenseCategory.gas,
  r'internet': ExpenseCategory.internet,
  r'tax': ExpenseCategory.tax,
  r'supplies': ExpenseCategory.supplies,
  r'maintenance': ExpenseCategory.maintenance,
  r'other': ExpenseCategory.other,
};
const _AccountingEntryincomeCategoryEnumValueMap = {
  r'sales': r'sales',
  r'manual': r'manual',
  r'other': r'other',
};
const _AccountingEntryincomeCategoryValueEnumMap = {
  r'sales': IncomeCategory.sales,
  r'manual': IncomeCategory.manual,
  r'other': IncomeCategory.other,
};
const _AccountingEntrykindEnumValueMap = {
  r'income': r'income',
  r'expense': r'expense',
};
const _AccountingEntrykindValueEnumMap = {
  r'income': AccountingKind.income,
  r'expense': AccountingKind.expense,
};

Id _accountingEntryGetId(AccountingEntry object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _accountingEntryGetLinks(AccountingEntry object) {
  return [];
}

void _accountingEntryAttach(
    IsarCollection<dynamic> col, Id id, AccountingEntry object) {
  object.id = id;
}

extension AccountingEntryQueryWhereSort
    on QueryBuilder<AccountingEntry, AccountingEntry, QWhere> {
  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhere> anyDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'date'),
      );
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhere> anyIsDeleted() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        const IndexWhereClause.any(indexName: r'isDeleted'),
      );
    });
  }
}

extension AccountingEntryQueryWhere
    on QueryBuilder<AccountingEntry, AccountingEntry, QWhereClause> {
  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause> idEqualTo(
      Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      idGreaterThan(Id id, {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause> idLessThan(
      Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause> dateEqualTo(
      DateTime date) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'date',
        value: [date],
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      dateNotEqualTo(DateTime date) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'date',
              lower: [],
              upper: [date],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'date',
              lower: [date],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'date',
              lower: [date],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'date',
              lower: [],
              upper: [date],
              includeUpper: false,
            ));
      }
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      dateGreaterThan(
    DateTime date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'date',
        lower: [date],
        includeLower: include,
        upper: [],
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      dateLessThan(
    DateTime date, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'date',
        lower: [],
        upper: [date],
        includeUpper: include,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause> dateBetween(
    DateTime lowerDate,
    DateTime upperDate, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.between(
        indexName: r'date',
        lower: [lowerDate],
        includeLower: includeLower,
        upper: [upperDate],
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      isDeletedEqualTo(bool isDeleted) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'isDeleted',
        value: [isDeleted],
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterWhereClause>
      isDeletedNotEqualTo(bool isDeleted) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDeleted',
              lower: [],
              upper: [isDeleted],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDeleted',
              lower: [isDeleted],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDeleted',
              lower: [isDeleted],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'isDeleted',
              lower: [],
              upper: [isDeleted],
              includeUpper: false,
            ));
      }
    });
  }
}

extension AccountingEntryQueryFilter
    on QueryBuilder<AccountingEntry, AccountingEntry, QFilterCondition> {
  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      amountKurusEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      amountKurusGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      amountKurusLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'amountKurus',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      amountKurusBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'amountKurus',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      createdAtEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      createdAtGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      createdAtLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'createdAt',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      createdAtBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'createdAt',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      dateEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      dateGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      dateLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'date',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      dateBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'date',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'expenseCategory',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'expenseCategory',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryEqualTo(
    ExpenseCategory? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryGreaterThan(
    ExpenseCategory? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryLessThan(
    ExpenseCategory? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryBetween(
    ExpenseCategory? lower,
    ExpenseCategory? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'expenseCategory',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'expenseCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'expenseCategory',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'expenseCategory',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      expenseCategoryIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'expenseCategory',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      idEqualTo(Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'incomeCategory',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'incomeCategory',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryEqualTo(
    IncomeCategory? value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryGreaterThan(
    IncomeCategory? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryLessThan(
    IncomeCategory? value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryBetween(
    IncomeCategory? lower,
    IncomeCategory? upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'incomeCategory',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'incomeCategory',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'incomeCategory',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'incomeCategory',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      incomeCategoryIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'incomeCategory',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      isDeletedEqualTo(bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isDeleted',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindEqualTo(
    AccountingKind value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindGreaterThan(
    AccountingKind value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindLessThan(
    AccountingKind value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindBetween(
    AccountingKind lower,
    AccountingKind upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'kind',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'kind',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'kind',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'kind',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      kindIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'kind',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'note',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'note',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'note',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      noteIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'note',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdIsNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNull(
        property: r'refOrderId',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdIsNotNull() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(const FilterCondition.isNotNull(
        property: r'refOrderId',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdEqualTo(int? value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdGreaterThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdLessThan(
    int? value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'refOrderId',
        value: value,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      refOrderIdBetween(
    int? lower,
    int? upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'refOrderId',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'title',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'title',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'title',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'title',
        value: '',
      ));
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterFilterCondition>
      titleIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'title',
        value: '',
      ));
    });
  }
}

extension AccountingEntryQueryObject
    on QueryBuilder<AccountingEntry, AccountingEntry, QFilterCondition> {}

extension AccountingEntryQueryLinks
    on QueryBuilder<AccountingEntry, AccountingEntry, QFilterCondition> {}

extension AccountingEntryQuerySortBy
    on QueryBuilder<AccountingEntry, AccountingEntry, QSortBy> {
  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByAmountKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> sortByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByExpenseCategory() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expenseCategory', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByExpenseCategoryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expenseCategory', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByIncomeCategory() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'incomeCategory', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByIncomeCategoryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'incomeCategory', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByIsDeleted() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDeleted', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByIsDeletedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDeleted', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> sortByKind() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'kind', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByKindDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'kind', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> sortByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByRefOrderIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> sortByTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'title', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      sortByTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'title', Sort.desc);
    });
  }
}

extension AccountingEntryQuerySortThenBy
    on QueryBuilder<AccountingEntry, AccountingEntry, QSortThenBy> {
  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByAmountKurusDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'amountKurus', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByCreatedAtDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'createdAt', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'date', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByExpenseCategory() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expenseCategory', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByExpenseCategoryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expenseCategory', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByIncomeCategory() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'incomeCategory', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByIncomeCategoryDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'incomeCategory', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByIsDeleted() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDeleted', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByIsDeletedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isDeleted', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenByKind() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'kind', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByKindDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'kind', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenByNote() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByNoteDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'note', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByRefOrderIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'refOrderId', Sort.desc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy> thenByTitle() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'title', Sort.asc);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QAfterSortBy>
      thenByTitleDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'title', Sort.desc);
    });
  }
}

extension AccountingEntryQueryWhereDistinct
    on QueryBuilder<AccountingEntry, AccountingEntry, QDistinct> {
  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByAmountKurus() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'amountKurus');
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByCreatedAt() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'createdAt');
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct> distinctByDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'date');
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByExpenseCategory({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'expenseCategory',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByIncomeCategory({bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'incomeCategory',
          caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByIsDeleted() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isDeleted');
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct> distinctByKind(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'kind', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct> distinctByNote(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'note', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct>
      distinctByRefOrderId() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'refOrderId');
    });
  }

  QueryBuilder<AccountingEntry, AccountingEntry, QDistinct> distinctByTitle(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'title', caseSensitive: caseSensitive);
    });
  }
}

extension AccountingEntryQueryProperty
    on QueryBuilder<AccountingEntry, AccountingEntry, QQueryProperty> {
  QueryBuilder<AccountingEntry, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<AccountingEntry, int, QQueryOperations> amountKurusProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'amountKurus');
    });
  }

  QueryBuilder<AccountingEntry, DateTime, QQueryOperations>
      createdAtProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'createdAt');
    });
  }

  QueryBuilder<AccountingEntry, DateTime, QQueryOperations> dateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'date');
    });
  }

  QueryBuilder<AccountingEntry, ExpenseCategory?, QQueryOperations>
      expenseCategoryProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'expenseCategory');
    });
  }

  QueryBuilder<AccountingEntry, IncomeCategory?, QQueryOperations>
      incomeCategoryProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'incomeCategory');
    });
  }

  QueryBuilder<AccountingEntry, bool, QQueryOperations> isDeletedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isDeleted');
    });
  }

  QueryBuilder<AccountingEntry, AccountingKind, QQueryOperations>
      kindProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'kind');
    });
  }

  QueryBuilder<AccountingEntry, String, QQueryOperations> noteProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'note');
    });
  }

  QueryBuilder<AccountingEntry, int?, QQueryOperations> refOrderIdProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'refOrderId');
    });
  }

  QueryBuilder<AccountingEntry, String, QQueryOperations> titleProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'title');
    });
  }
}
