// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'license_collection.dart';

// **************************************************************************
// IsarCollectionGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: duplicate_ignore, non_constant_identifier_names, constant_identifier_names, invalid_use_of_protected_member, unnecessary_cast, prefer_const_constructors, lines_longer_than_80_chars, require_trailing_commas, inference_failure_on_function_invocation, unnecessary_parenthesis, unnecessary_raw_strings, unnecessary_null_checks, join_return_with_assignment, prefer_final_locals, avoid_js_rounded_ints, avoid_positional_boolean_parameters, always_specify_types

extension GetAppLicenseCollection on Isar {
  IsarCollection<AppLicense> get appLicenses => this.collection();
}

const AppLicenseSchema = CollectionSchema(
  name: r'AppLicense',
  id: 5629675031459234435,
  properties: {
    r'expirationDate': PropertySchema(
      id: 0,
      name: r'expirationDate',
      type: IsarType.dateTime,
    ),
    r'isActive': PropertySchema(
      id: 1,
      name: r'isActive',
      type: IsarType.bool,
    ),
    r'isExpired': PropertySchema(
      id: 2,
      name: r'isExpired',
      type: IsarType.bool,
    ),
    r'lastChecked': PropertySchema(
      id: 3,
      name: r'lastChecked',
      type: IsarType.dateTime,
    ),
    r'licenseKey': PropertySchema(
      id: 4,
      name: r'licenseKey',
      type: IsarType.string,
    ),
    r'offlineToleranceDays': PropertySchema(
      id: 5,
      name: r'offlineToleranceDays',
      type: IsarType.long,
    ),
    r'registeredTo': PropertySchema(
      id: 6,
      name: r'registeredTo',
      type: IsarType.string,
    )
  },
  estimateSize: _appLicenseEstimateSize,
  serialize: _appLicenseSerialize,
  deserialize: _appLicenseDeserialize,
  deserializeProp: _appLicenseDeserializeProp,
  idName: r'id',
  indexes: {
    r'licenseKey': IndexSchema(
      id: 1918007530406205730,
      name: r'licenseKey',
      unique: true,
      replace: false,
      properties: [
        IndexPropertySchema(
          name: r'licenseKey',
          type: IndexType.hash,
          caseSensitive: true,
        )
      ],
    )
  },
  links: {},
  embeddedSchemas: {},
  getId: _appLicenseGetId,
  getLinks: _appLicenseGetLinks,
  attach: _appLicenseAttach,
  version: '3.3.2',
);

int _appLicenseEstimateSize(
  AppLicense object,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  var bytesCount = offsets.last;
  bytesCount += 3 + object.licenseKey.length * 3;
  bytesCount += 3 + object.registeredTo.length * 3;
  return bytesCount;
}

void _appLicenseSerialize(
  AppLicense object,
  IsarWriter writer,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  writer.writeDateTime(offsets[0], object.expirationDate);
  writer.writeBool(offsets[1], object.isActive);
  writer.writeBool(offsets[2], object.isExpired);
  writer.writeDateTime(offsets[3], object.lastChecked);
  writer.writeString(offsets[4], object.licenseKey);
  writer.writeLong(offsets[5], object.offlineToleranceDays);
  writer.writeString(offsets[6], object.registeredTo);
}

AppLicense _appLicenseDeserialize(
  Id id,
  IsarReader reader,
  List<int> offsets,
  Map<Type, List<int>> allOffsets,
) {
  final object = AppLicense();
  object.expirationDate = reader.readDateTime(offsets[0]);
  object.id = id;
  object.isActive = reader.readBool(offsets[1]);
  object.lastChecked = reader.readDateTime(offsets[3]);
  object.licenseKey = reader.readString(offsets[4]);
  object.offlineToleranceDays = reader.readLong(offsets[5]);
  object.registeredTo = reader.readString(offsets[6]);
  return object;
}

P _appLicenseDeserializeProp<P>(
  IsarReader reader,
  int propertyId,
  int offset,
  Map<Type, List<int>> allOffsets,
) {
  switch (propertyId) {
    case 0:
      return (reader.readDateTime(offset)) as P;
    case 1:
      return (reader.readBool(offset)) as P;
    case 2:
      return (reader.readBool(offset)) as P;
    case 3:
      return (reader.readDateTime(offset)) as P;
    case 4:
      return (reader.readString(offset)) as P;
    case 5:
      return (reader.readLong(offset)) as P;
    case 6:
      return (reader.readString(offset)) as P;
    default:
      throw IsarError('Unknown property with id $propertyId');
  }
}

Id _appLicenseGetId(AppLicense object) {
  return object.id;
}

List<IsarLinkBase<dynamic>> _appLicenseGetLinks(AppLicense object) {
  return [];
}

void _appLicenseAttach(IsarCollection<dynamic> col, Id id, AppLicense object) {
  object.id = id;
}

extension AppLicenseByIndex on IsarCollection<AppLicense> {
  Future<AppLicense?> getByLicenseKey(String licenseKey) {
    return getByIndex(r'licenseKey', [licenseKey]);
  }

  AppLicense? getByLicenseKeySync(String licenseKey) {
    return getByIndexSync(r'licenseKey', [licenseKey]);
  }

  Future<bool> deleteByLicenseKey(String licenseKey) {
    return deleteByIndex(r'licenseKey', [licenseKey]);
  }

  bool deleteByLicenseKeySync(String licenseKey) {
    return deleteByIndexSync(r'licenseKey', [licenseKey]);
  }

  Future<List<AppLicense?>> getAllByLicenseKey(List<String> licenseKeyValues) {
    final values = licenseKeyValues.map((e) => [e]).toList();
    return getAllByIndex(r'licenseKey', values);
  }

  List<AppLicense?> getAllByLicenseKeySync(List<String> licenseKeyValues) {
    final values = licenseKeyValues.map((e) => [e]).toList();
    return getAllByIndexSync(r'licenseKey', values);
  }

  Future<int> deleteAllByLicenseKey(List<String> licenseKeyValues) {
    final values = licenseKeyValues.map((e) => [e]).toList();
    return deleteAllByIndex(r'licenseKey', values);
  }

  int deleteAllByLicenseKeySync(List<String> licenseKeyValues) {
    final values = licenseKeyValues.map((e) => [e]).toList();
    return deleteAllByIndexSync(r'licenseKey', values);
  }

  Future<Id> putByLicenseKey(AppLicense object) {
    return putByIndex(r'licenseKey', object);
  }

  Id putByLicenseKeySync(AppLicense object, {bool saveLinks = true}) {
    return putByIndexSync(r'licenseKey', object, saveLinks: saveLinks);
  }

  Future<List<Id>> putAllByLicenseKey(List<AppLicense> objects) {
    return putAllByIndex(r'licenseKey', objects);
  }

  List<Id> putAllByLicenseKeySync(List<AppLicense> objects,
      {bool saveLinks = true}) {
    return putAllByIndexSync(r'licenseKey', objects, saveLinks: saveLinks);
  }
}

extension AppLicenseQueryWhereSort
    on QueryBuilder<AppLicense, AppLicense, QWhere> {
  QueryBuilder<AppLicense, AppLicense, QAfterWhere> anyId() {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(const IdWhereClause.any());
    });
  }
}

extension AppLicenseQueryWhere
    on QueryBuilder<AppLicense, AppLicense, QWhereClause> {
  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> idEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: id,
        upper: id,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> idNotEqualTo(Id id) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            )
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            );
      } else {
        return query
            .addWhereClause(
              IdWhereClause.greaterThan(lower: id, includeLower: false),
            )
            .addWhereClause(
              IdWhereClause.lessThan(upper: id, includeUpper: false),
            );
      }
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> idGreaterThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.greaterThan(lower: id, includeLower: include),
      );
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> idLessThan(Id id,
      {bool include = false}) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(
        IdWhereClause.lessThan(upper: id, includeUpper: include),
      );
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> idBetween(
    Id lowerId,
    Id upperId, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IdWhereClause.between(
        lower: lowerId,
        includeLower: includeLower,
        upper: upperId,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> licenseKeyEqualTo(
      String licenseKey) {
    return QueryBuilder.apply(this, (query) {
      return query.addWhereClause(IndexWhereClause.equalTo(
        indexName: r'licenseKey',
        value: [licenseKey],
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterWhereClause> licenseKeyNotEqualTo(
      String licenseKey) {
    return QueryBuilder.apply(this, (query) {
      if (query.whereSort == Sort.asc) {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'licenseKey',
              lower: [],
              upper: [licenseKey],
              includeUpper: false,
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'licenseKey',
              lower: [licenseKey],
              includeLower: false,
              upper: [],
            ));
      } else {
        return query
            .addWhereClause(IndexWhereClause.between(
              indexName: r'licenseKey',
              lower: [licenseKey],
              includeLower: false,
              upper: [],
            ))
            .addWhereClause(IndexWhereClause.between(
              indexName: r'licenseKey',
              lower: [],
              upper: [licenseKey],
              includeUpper: false,
            ));
      }
    });
  }
}

extension AppLicenseQueryFilter
    on QueryBuilder<AppLicense, AppLicense, QFilterCondition> {
  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      expirationDateEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'expirationDate',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      expirationDateGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'expirationDate',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      expirationDateLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'expirationDate',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      expirationDateBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'expirationDate',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> idEqualTo(
      Id value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> idGreaterThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> idLessThan(
    Id value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'id',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> idBetween(
    Id lower,
    Id upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'id',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> isActiveEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isActive',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> isExpiredEqualTo(
      bool value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'isExpired',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      lastCheckedEqualTo(DateTime value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'lastChecked',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      lastCheckedGreaterThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'lastChecked',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      lastCheckedLessThan(
    DateTime value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'lastChecked',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      lastCheckedBetween(
    DateTime lower,
    DateTime upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'lastChecked',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> licenseKeyEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> licenseKeyBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'licenseKey',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'licenseKey',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition> licenseKeyMatches(
      String pattern,
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'licenseKey',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'licenseKey',
        value: '',
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      licenseKeyIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'licenseKey',
        value: '',
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      offlineToleranceDaysEqualTo(int value) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'offlineToleranceDays',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      offlineToleranceDaysGreaterThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'offlineToleranceDays',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      offlineToleranceDaysLessThan(
    int value, {
    bool include = false,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'offlineToleranceDays',
        value: value,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      offlineToleranceDaysBetween(
    int lower,
    int upper, {
    bool includeLower = true,
    bool includeUpper = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'offlineToleranceDays',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToEqualTo(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToGreaterThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        include: include,
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToLessThan(
    String value, {
    bool include = false,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.lessThan(
        include: include,
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToBetween(
    String lower,
    String upper, {
    bool includeLower = true,
    bool includeUpper = true,
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.between(
        property: r'registeredTo',
        lower: lower,
        includeLower: includeLower,
        upper: upper,
        includeUpper: includeUpper,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToStartsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.startsWith(
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToEndsWith(
    String value, {
    bool caseSensitive = true,
  }) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.endsWith(
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToContains(String value, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.contains(
        property: r'registeredTo',
        value: value,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToMatches(String pattern, {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.matches(
        property: r'registeredTo',
        wildcard: pattern,
        caseSensitive: caseSensitive,
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToIsEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.equalTo(
        property: r'registeredTo',
        value: '',
      ));
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterFilterCondition>
      registeredToIsNotEmpty() {
    return QueryBuilder.apply(this, (query) {
      return query.addFilterCondition(FilterCondition.greaterThan(
        property: r'registeredTo',
        value: '',
      ));
    });
  }
}

extension AppLicenseQueryObject
    on QueryBuilder<AppLicense, AppLicense, QFilterCondition> {}

extension AppLicenseQueryLinks
    on QueryBuilder<AppLicense, AppLicense, QFilterCondition> {}

extension AppLicenseQuerySortBy
    on QueryBuilder<AppLicense, AppLicense, QSortBy> {
  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByExpirationDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expirationDate', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      sortByExpirationDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expirationDate', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByIsActive() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isActive', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByIsActiveDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isActive', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByIsExpired() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isExpired', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByIsExpiredDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isExpired', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByLastChecked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastChecked', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByLastCheckedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastChecked', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByLicenseKey() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'licenseKey', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByLicenseKeyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'licenseKey', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      sortByOfflineToleranceDays() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'offlineToleranceDays', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      sortByOfflineToleranceDaysDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'offlineToleranceDays', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByRegisteredTo() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'registeredTo', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> sortByRegisteredToDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'registeredTo', Sort.desc);
    });
  }
}

extension AppLicenseQuerySortThenBy
    on QueryBuilder<AppLicense, AppLicense, QSortThenBy> {
  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByExpirationDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expirationDate', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      thenByExpirationDateDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'expirationDate', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenById() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByIdDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'id', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByIsActive() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isActive', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByIsActiveDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isActive', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByIsExpired() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isExpired', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByIsExpiredDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'isExpired', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByLastChecked() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastChecked', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByLastCheckedDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'lastChecked', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByLicenseKey() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'licenseKey', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByLicenseKeyDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'licenseKey', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      thenByOfflineToleranceDays() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'offlineToleranceDays', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy>
      thenByOfflineToleranceDaysDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'offlineToleranceDays', Sort.desc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByRegisteredTo() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'registeredTo', Sort.asc);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QAfterSortBy> thenByRegisteredToDesc() {
    return QueryBuilder.apply(this, (query) {
      return query.addSortBy(r'registeredTo', Sort.desc);
    });
  }
}

extension AppLicenseQueryWhereDistinct
    on QueryBuilder<AppLicense, AppLicense, QDistinct> {
  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByExpirationDate() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'expirationDate');
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByIsActive() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isActive');
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByIsExpired() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'isExpired');
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByLastChecked() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'lastChecked');
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByLicenseKey(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'licenseKey', caseSensitive: caseSensitive);
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct>
      distinctByOfflineToleranceDays() {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'offlineToleranceDays');
    });
  }

  QueryBuilder<AppLicense, AppLicense, QDistinct> distinctByRegisteredTo(
      {bool caseSensitive = true}) {
    return QueryBuilder.apply(this, (query) {
      return query.addDistinctBy(r'registeredTo', caseSensitive: caseSensitive);
    });
  }
}

extension AppLicenseQueryProperty
    on QueryBuilder<AppLicense, AppLicense, QQueryProperty> {
  QueryBuilder<AppLicense, int, QQueryOperations> idProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'id');
    });
  }

  QueryBuilder<AppLicense, DateTime, QQueryOperations>
      expirationDateProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'expirationDate');
    });
  }

  QueryBuilder<AppLicense, bool, QQueryOperations> isActiveProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isActive');
    });
  }

  QueryBuilder<AppLicense, bool, QQueryOperations> isExpiredProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'isExpired');
    });
  }

  QueryBuilder<AppLicense, DateTime, QQueryOperations> lastCheckedProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'lastChecked');
    });
  }

  QueryBuilder<AppLicense, String, QQueryOperations> licenseKeyProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'licenseKey');
    });
  }

  QueryBuilder<AppLicense, int, QQueryOperations>
      offlineToleranceDaysProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'offlineToleranceDays');
    });
  }

  QueryBuilder<AppLicense, String, QQueryOperations> registeredToProperty() {
    return QueryBuilder.apply(this, (query) {
      return query.addPropertyName(r'registeredTo');
    });
  }
}
